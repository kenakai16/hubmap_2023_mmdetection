# Copyright (c) OpenMMLab. All rights reserved.
from .config import Config, ConfigDict, DictAction

__all__ = ['Config', 'ConfigDict', 'DictAction']
